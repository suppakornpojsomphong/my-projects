-- Create the Database and use it
CREATE DATABASE [P4_G17_077_144_191];
GO
USE [P4_G17_077_144_191];
GO
IF OBJECT_ID('dbo.BusinessOwner', 'U') IS NOT NULL DROP TABLE dbo.BusinessOwner;

-- Table BusinessOwner
CREATE TABLE [BusinessOwner](
    bo_citizen_id VARCHAR(13) NOT NULL,
    bo_username    VARCHAR(20) NOT NULL,
    bo_password    VARCHAR(20) NOT NULL,
    bo_fname       VARCHAR(20) NOT NULL,
    bo_lname       VARCHAR(20) NOT NULL,
    bo_gender      VARCHAR(10) NOT NULL 
        CONSTRAINT CHK_BusinessOwner_bo_gender CHECK (bo_gender IN ('Female', 'Male', 'Other'))
);
ALTER TABLE [BusinessOwner]
    ADD CONSTRAINT PK_BusinessOwner PRIMARY KEY (bo_citizen_id);
GO

IF OBJECT_ID('dbo.[Branch]', 'U') IS NOT NULL DROP TABLE dbo.[Branch];

-- Table Branch
CREATE TABLE [Branch](
    branch_id            VARCHAR(13) NOT NULL,
    branch_name          VARCHAR(20) NOT NULL,
    branch_street        VARCHAR(20) NOT NULL,
    branch_city          VARCHAR(20) NOT NULL,
    branch_postcode      VARCHAR(10) NOT NULL,
    branch_phone         VARCHAR(13) NOT NULL,
    branch_stockQuantity INT NOT NULL,
    branch_noOfEmployees INT NOT NULL,
    branch_opening       TIME NOT NULL,
    branch_closing       TIME NOT NULL,
    branch_bo_citizen_id VARCHAR(13) NOT NULL,
    CONSTRAINT PK_Branch PRIMARY KEY (branch_id),
    CONSTRAINT FK_Branch_BusinessOwner FOREIGN KEY (branch_bo_citizen_id) REFERENCES [BusinessOwner](bo_citizen_id)
);
GO

IF OBJECT_ID('dbo.[Staff]', 'U') IS NOT NULL DROP TABLE dbo.[Staff];
-- Table Staff
CREATE TABLE [Staff](
    staff_id         VARCHAR(13) NOT NULL,
    staff_citizenID  VARCHAR(13) NOT NULL,
    staff_username   VARCHAR(20) NOT NULL,
    staff_password   VARCHAR(20) NOT NULL,
    staff_fname      VARCHAR(20) NOT NULL,
    staff_lname      VARCHAR(20) NOT NULL,
    staff_email      VARCHAR(40) NOT NULL,
    staff_gender     VARCHAR(10) NOT NULL 
        CONSTRAINT CHK_Staff_gender CHECK (staff_gender IN ('Female', 'Male', 'Other')),
    staff_salary     VARCHAR(10) NOT NULL,
    staff_dob        DATE NOT NULL,
    staff_hireDate   DATE NOT NULL,
    staff_branch_id  VARCHAR(13) NOT NULL,
    CONSTRAINT PK_Staff PRIMARY KEY (staff_id),
    CONSTRAINT FK_Staff_Branch FOREIGN KEY (staff_branch_id) REFERENCES [Branch](branch_id)
);
GO

IF OBJECT_ID('dbo.[Chef]', 'U') IS NOT NULL DROP TABLE dbo.[Chef];

-- Table Chef
CREATE TABLE [Chef](
    chef_staff_id       VARCHAR(13) NOT NULL,
    chef_specialty      VARCHAR(40) NOT NULL,
    chef_experienceYears INT NOT NULL,
    chef_certification  VARCHAR(200),
    CONSTRAINT PK_Chef PRIMARY KEY (chef_staff_id),
    CONSTRAINT FK_Chef_Staff FOREIGN KEY (chef_staff_id) REFERENCES [Staff](staff_id)
);
GO

IF OBJECT_ID('dbo.[Waiter]', 'U') IS NOT NULL DROP TABLE dbo.[Waiter];

-- Table Waiter 
CREATE TABLE [Waiter](
    waiter_staff_id    VARCHAR(13) NOT NULL,
    waiter_assignedArea VARCHAR(30) NOT NULL,
    waiter_shift       VARCHAR(20) NOT NULL 
        CONSTRAINT CHK_Waiter_shift CHECK (waiter_shift IN ('Morning', 'Afternoon', 'Night')),
    CONSTRAINT PK_Waiter PRIMARY KEY (waiter_staff_id),
    CONSTRAINT FK_Waiter_Staff FOREIGN KEY (waiter_staff_id) REFERENCES [Staff](staff_id)
);
GO

IF OBJECT_ID('dbo.[GeneralManager]', 'U') IS NOT NULL DROP TABLE dbo.[GeneralManager];

-- Table GeneralManager 
CREATE TABLE [GeneralManager](
    gm_staff_id         VARCHAR(13) NOT NULL,
    gm_responsibility   VARCHAR(30) NOT NULL,
    gm_experienceYears  INT NOT NULL,
    gm_authorityLevel   VARCHAR(20) NOT NULL 
        CONSTRAINT CHK_GM_authority CHECK (gm_authorityLevel IN ('Full', 'Partial')),
    CONSTRAINT PK_GeneralManager PRIMARY KEY (gm_staff_id),
    CONSTRAINT FK_GeneralManager_Staff FOREIGN KEY (gm_staff_id) REFERENCES [Staff](staff_id)
);
GO

IF OBJECT_ID('dbo.[StockController]', 'U') IS NOT NULL DROP TABLE dbo.[StockController];

-- Table StockController 
CREATE TABLE [StockController](
    sc_staff_id       VARCHAR(13) NOT NULL,
    sc_warehouseZone  VARCHAR(30) NOT NULL,
    CONSTRAINT PK_StockController PRIMARY KEY (sc_staff_id),
    CONSTRAINT FK_StockController_Staff FOREIGN KEY (sc_staff_id) REFERENCES [Staff](staff_id)
);
GO

IF OBJECT_ID('dbo.[Menu]', 'U') IS NOT NULL DROP TABLE dbo.[Menu];

-- Table Menu
CREATE TABLE [Menu](
    menu_id          VARCHAR(13) NOT NULL,
    menu_name        VARCHAR(50) NOT NULL,
    menu_description VARCHAR(500) NOT NULL,
    menu_price       FLOAT NOT NULL,
    menu_category    VARCHAR(20) NOT NULL,
    menu_prepTime    VARCHAR(10) NOT NULL,
    CONSTRAINT PK_Menu PRIMARY KEY (menu_id)
);
GO

IF OBJECT_ID('dbo.[Customer]', 'U') IS NOT NULL DROP TABLE dbo.[Customer];

-- Table Customer 
CREATE TABLE [Customer](
    cus_id         VARCHAR(13) NOT NULL,
    cus_citizenID  VARCHAR(13) NOT NULL,
    cus_fname      VARCHAR(20) NOT NULL,
    cus_lname      VARCHAR(20) NOT NULL,
    cus_email      VARCHAR(20) NOT NULL,
    cus_phone      VARCHAR(13) NOT NULL,
    cus_gender     VARCHAR(10) NOT NULL 
        CONSTRAINT CHK_Customer_gender CHECK (cus_gender IN ('Female', 'Male', 'Other')),
    cus_created_at DATETIME NOT NULL,
    cus_dob        DATE NOT NULL,
    CONSTRAINT PK_Customer PRIMARY KEY (cus_id)
);
GO

IF OBJECT_ID('dbo.[Order]', 'U') IS NOT NULL DROP TABLE dbo.[Order];

-- Table Order (reserved word, so enclosed in square brackets)
CREATE TABLE [Order](
    order_id         VARCHAR(13) NOT NULL,
    order_date       DATETIME NOT NULL,
    order_totalPrice FLOAT NOT NULL,
    order_status     VARCHAR(20) NOT NULL 
        CONSTRAINT CHK_Order_status CHECK (order_status IN ('Pending', 'Completed', 'Canceled')),
    order_deliveryType VARCHAR(20) NOT NULL,
    CONSTRAINT PK_Order PRIMARY KEY (order_id)
);
GO

IF OBJECT_ID('dbo.[ConsistOf]', 'U') IS NOT NULL DROP TABLE dbo.[ConsistOf];

-- Table ConsistOf
CREATE TABLE [ConsistOf](
    consist_order_id    VARCHAR(13) NOT NULL,
    consist_menu_id     VARCHAR(13) NOT NULL,
    consist_quantity    INT NOT NULL,
    consist_price       FLOAT NOT NULL,
    consist_specialRequest VARCHAR(500),
    CONSTRAINT PK_ConsistOf PRIMARY KEY (consist_order_id, consist_menu_id),
    CONSTRAINT FK_ConsistOf_Order FOREIGN KEY (consist_order_id) REFERENCES [Order](order_id),
    CONSTRAINT FK_ConsistOf_Menu FOREIGN KEY (consist_menu_id) REFERENCES [Menu](menu_id)
);
GO

IF OBJECT_ID('dbo.[Payment]', 'U') IS NOT NULL DROP TABLE dbo.[Payment];

-- Table Payment
CREATE TABLE [Payment](
    payment_id              VARCHAR(13) NOT NULL,
    payment_method          VARCHAR(30) NOT NULL,
    payment_status          VARCHAR(20) NOT NULL 
         CONSTRAINT CHK_Payment_status CHECK (payment_status IN ('Pending', 'Completed', 'Failed')),
    payment_transactionDate DATETIME NOT NULL,
    payment_amount          FLOAT NOT NULL,
    payment_order_id        VARCHAR(13) NOT NULL,
    CONSTRAINT PK_Payment PRIMARY KEY (payment_id),
    CONSTRAINT FK_Payment_Order FOREIGN KEY (payment_order_id) REFERENCES [Order](order_id)
);
GO

IF OBJECT_ID('dbo.[Feedback]', 'U') IS NOT NULL DROP TABLE dbo.[Feedback];

-- Table Feedback
CREATE TABLE [Feedback](
    feedback_id    VARCHAR(13) NOT NULL,
    feedback_rating INT NOT NULL,
    feedback_comment VARCHAR(500),
    feedback_cus_id VARCHAR(13) NOT NULL,
    CONSTRAINT PK_Feedback PRIMARY KEY (feedback_id),
    CONSTRAINT FK_Feedback_Customer FOREIGN KEY (feedback_cus_id) REFERENCES [Customer](cus_id)
);
GO

IF OBJECT_ID('dbo.[Promotion]', 'U') IS NOT NULL DROP TABLE dbo.[Promotion];

-- Table Promotion
CREATE TABLE [Promotion](
    pro_id             VARCHAR(13) NOT NULL,
    pro_name           VARCHAR(20) NOT NULL,
    pro_description    VARCHAR(500) NOT NULL,
    pro_discounPercentage FLOAT NOT NULL,
    pro_startDate      DATE NOT NULL,
    pro_endDate        DATE NOT NULL,
    pro_usageLimit     INT NOT NULL,
    pro_usageCount     INT NOT NULL,
    pro_isActive       BIT NOT NULL,
    CONSTRAINT PK_Promotion PRIMARY KEY (pro_id)
);
GO

IF OBJECT_ID('dbo.[Apply]', 'U') IS NOT NULL DROP TABLE dbo.[Apply];

-- Table Apply 
CREATE TABLE [Apply](
    apply_menu_id             VARCHAR(13) NOT NULL,
    apply_pro_id              VARCHAR(13) NOT NULL,
    apply_discountValue       FLOAT NOT NULL,
    apply_discountType        VARCHAR(20) NOT NULL,
    apply_minPurchase         INT NOT NULL,
    apply_maxUsagePerCustomer INT NOT NULL,
    apply_conditions          VARCHAR(500) NOT NULL,
    CONSTRAINT PK_Apply PRIMARY KEY (apply_menu_id, apply_pro_id),
    CONSTRAINT FK_Apply_Menu FOREIGN KEY (apply_menu_id) REFERENCES [Menu](menu_id),
    CONSTRAINT FK_Apply_Promotion FOREIGN KEY (apply_pro_id) REFERENCES [Promotion](pro_id)
);
GO

IF OBJECT_ID('dbo.[Use]', 'U') IS NOT NULL DROP TABLE dbo.[Use];

-- Table Use (reserved word, so enclosed in square brackets)
CREATE TABLE [Use](
    use_pro_id    VARCHAR(13) NOT NULL,
    use_cus_id    VARCHAR(13) NOT NULL,
    use_usageCount INT NOT NULL, 
    use_lastUsed  DATETIME NOT NULL,
    use_isEligible BIT NOT NULL,
    CONSTRAINT PK_Use PRIMARY KEY (use_pro_id, use_cus_id),
    CONSTRAINT FK_Use_Promotion FOREIGN KEY (use_pro_id) REFERENCES [Promotion](pro_id),
    CONSTRAINT FK_Use_Customer FOREIGN KEY (use_cus_id) REFERENCES [Customer](cus_id)
);
GO

IF OBJECT_ID('dbo.[Supplier]', 'U') IS NOT NULL DROP TABLE dbo.[Supplier];

-- Table Supplier
CREATE TABLE [Supplier](
    sup_id          VARCHAR(13) NOT NULL,
    sup_address     VARCHAR(100) NOT NULL, 
    sup_companyName VARCHAR(20) NOT NULL,
    sup_contact     VARCHAR(50) NOT NULL,
    CONSTRAINT PK_Supplier PRIMARY KEY (sup_id)
);
GO

IF OBJECT_ID('dbo.[Contact]', 'U') IS NOT NULL DROP TABLE dbo.[Contact];

-- Table Contact 
CREATE TABLE [Contact](
    contact_staff_id VARCHAR(13) NOT NULL,
    contact_sup_id   VARCHAR(13) NOT NULL, 
    contact_date     DATE NOT NULL,
    contact_type     VARCHAR(50) NOT NULL,
    contact_details  VARCHAR(100) NOT NULL,
    contact_status   VARCHAR(50) NOT NULL,
    contact_notes    VARCHAR(500) NOT NULL,
    CONSTRAINT PK_Contact PRIMARY KEY (contact_staff_id, contact_sup_id),
    CONSTRAINT FK_Contact_Staff FOREIGN KEY (contact_staff_id) REFERENCES [Staff](staff_id),
    CONSTRAINT FK_Contact_Supplier FOREIGN KEY (contact_sup_id) REFERENCES [Supplier](sup_id)
);
GO

IF OBJECT_ID('dbo.[Ingredient]', 'U') IS NOT NULL DROP TABLE dbo.[Ingredient];

-- Table Ingredient
CREATE TABLE [Ingredient](
    ing_id          VARCHAR(13) NOT NULL, 
    ing_name        VARCHAR(20) NOT NULL, 
    ing_quantity    INT NOT NULL,
    ing_unit        VARCHAR(30) NOT NULL,
    ing_costPerUnit FLOAT NOT NULL,
    ing_expiryDate  DATE NOT NULL,
    ing_sup_id      VARCHAR(13) NOT NULL,
    CONSTRAINT PK_Ingredient PRIMARY KEY (ing_id),
    CONSTRAINT FK_Ingredient_Supplier FOREIGN KEY (ing_sup_id) REFERENCES [Supplier](sup_id)
);
GO

IF OBJECT_ID('dbo.[Check]','U') IS NOT NULL DROP TABLE dbo.[Check];

-- Table Check (reserved word, so enclosed in square brackets)
CREATE TABLE [Check](
    check_staff_id VARCHAR(13) NOT NULL, 
    check_ing_id   VARCHAR(13) NOT NULL, 
    check_date     DATE NOT NULL,
    check_quantity INT NOT NULL,
    check_status   VARCHAR(20) NOT NULL 
         CONSTRAINT CHK_Check_status CHECK (check_status IN ('Completed', 'Pending', 'Discrepancy')),
    check_comments VARCHAR(500) NOT NULL,
    CONSTRAINT PK_Check PRIMARY KEY (check_staff_id, check_ing_id),
    CONSTRAINT FK_Check_Staff FOREIGN KEY (check_staff_id) REFERENCES [Staff](staff_id),
    CONSTRAINT FK_Check_Ingredient FOREIGN KEY (check_ing_id) REFERENCES [Ingredient](ing_id)
);
GO

IF OBJECT_ID('dbo.[MadeUpOf]', 'U') IS NOT NULL DROP TABLE dbo.[MadeUpOf];

-- Table MadeUpOf 
CREATE TABLE [MadeUpOf](
    ingredient_menu_id VARCHAR(13) NOT NULL, 
    ingredient_ing_id  VARCHAR(13) NOT NULL, 
    ingredient_quantity VARCHAR(100) NOT NULL,
    CONSTRAINT PK_MadeUpOf PRIMARY KEY (ingredient_menu_id, ingredient_ing_id),
    CONSTRAINT FK_MadeUpOf_Menu FOREIGN KEY (ingredient_menu_id) REFERENCES [Menu](menu_id),
    CONSTRAINT FK_MadeUpOf_Ingredient FOREIGN KEY (ingredient_ing_id) REFERENCES [Ingredient](ing_id)
);
GO
